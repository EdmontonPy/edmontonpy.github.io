import wx

class MyFrame(wx.Frame):
    def __init__(self, parent=None, 
                 id=wx.ID_ANY, title=''):
        wx.Frame.__init__(self, parent, id, title)        
        self.panel = wx.Panel(self)
        self.hello = wx.StaticText(self.panel, wx.ID_ANY,
                                   "Hello Again Using Classes", 
                                   style=wx.ALIGN_CENTER)

        frame_sizer = wx.BoxSizer(wx.VERTICAL)
        frame_sizer.Add(self.panel, 1, wx.EXPAND)
        self.SetSizer(frame_sizer)
        
        panel_sizer = wx.BoxSizer(wx.VERTICAL)
        panel_sizer.Add(self.hello, 1, wx.EXPAND)
        self.panel.SetSizer(panel_sizer)
        
        font = wx.Font(32, wx.DEFAULT, wx.NORMAL, wx.BOLD)
        font.SetFaceName('French Script MT')
        self.hello.SetFont(font)
    
class MyApp(wx.App):
    def OnInit(self):
        self.frame = MyFrame(None, wx.ID_ANY, "Hello World")
        self.SetTopWindow(self.frame)
        self.frame.Show(True)
        return True

if __name__ == '__main__':
    app = MyApp()
    app.MainLoop()