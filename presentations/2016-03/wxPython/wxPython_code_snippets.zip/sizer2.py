import wx
app = wx.App()
frame = wx.Frame(None, wx.ID_ANY, "Hello Sizer")

sizer = wx.BoxSizer(wx.VERTICAL)
frame.SetSizer(sizer)
buttons = []
for i in range(5):
	button = wx.Button(frame, wx.ID_ANY, 
					   "button"+str(i))
	buttons.append(button)
for i in range(3):
	sizer.Add(buttons[i])
sizer.Add(buttons[3], 1, wx.EXPAND)
sizer.Add(buttons[4], 2)

frame.Show(True)
app.MainLoop()