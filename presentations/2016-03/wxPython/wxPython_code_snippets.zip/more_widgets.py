import wx
app = wx.App()
frame = wx.Frame(None, wx.ID_ANY, "Hello Sizer")

for i in range(5):
	button = wx.Button(frame, wx.ID_ANY, 
					   "button"+str(i))

frame.Show(True)
app.MainLoop()