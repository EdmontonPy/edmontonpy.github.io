import wx

app = wx.App()
frame = wx.Frame(None, wx.ID_ANY, "Hello World")
hello = wx.StaticText(frame, wx.ID_ANY, 
					  "Hello Again", 
					  style=wx.ALIGN_CENTER)
frame.Show(True)
app.MainLoop()