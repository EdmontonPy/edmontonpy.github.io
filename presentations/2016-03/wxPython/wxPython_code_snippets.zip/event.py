import wx

app = wx.App()
frame = wx.Frame(None, wx.ID_ANY, "Event Handler")
sizer = wx.BoxSizer(wx.VERTICAL)
frame.SetSizer(sizer)
red_button = wx.Button(frame, wx.ID_ANY, "Make It Red!")
sizer.Add(red_button)
blue_button = wx.Button(frame, wx.ID_ANY, "Make It Blue")
sizer.Add(blue_button)

def on_red_click(event):
	frame.SetBackgroundColour(wx.RED)
	frame.Refresh()
def on_blue_click(event):
	frame.SetBackgroundColour(wx.BLUE)
	frame.Refresh()
frame.Bind(wx.EVT_BUTTON, on_red_click, red_button)
frame.Bind(wx.EVT_BUTTON, on_blue_click, blue_button)

frame.Show(True)
app.MainLoop()