import wx
app = wx.App()
frame = wx.Frame(None, wx.ID_ANY, "Hello Sizer")

sizer = wx.BoxSizer(wx.VERTICAL)
frame.SetSizer(sizer)
for i in range(5):
	button = wx.Button(frame, wx.ID_ANY, 
					   "button"+str(i))
	sizer.Add(button)

frame.Show(True)
app.MainLoop()